$dir = "C:\Portable Apps\GamesaveCloud"
Start-Process -FilePath "$dir\GamesaveCloudCLI.exe" "-t `"Playnite`" -s onedrive -d fromcloud" -Wait -WindowStyle Minimized -WorkingDirectory "$dir"
